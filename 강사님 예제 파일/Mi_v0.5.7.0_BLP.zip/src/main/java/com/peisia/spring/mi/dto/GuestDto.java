package com.peisia.spring.mi.dto;

import lombok.Data;

@Data
public class GuestDto {
	private Long bno;
	private String btext;
}