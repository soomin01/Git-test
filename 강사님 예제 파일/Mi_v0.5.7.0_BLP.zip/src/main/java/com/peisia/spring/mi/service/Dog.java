package com.peisia.spring.mi.service;

public class Dog {

}
